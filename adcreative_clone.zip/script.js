
document.addEventListener('DOMContentLoaded', () => {
  console.log('SmartAdGen.ai landing page loaded.');
});
